package user;

public class signup {
    
    private String name;
    private String email;
    private int phone;
    private String password;

    public signup() {
    }

    public signup(String name, String email, int phone, String password) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public int getPhone() {
        return phone;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "signup{" + "name=" + name + ", email=" + email + ", phone=" + phone + ", password=" + password + '}';
    }
    
    
}
