/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Hp
 */
public class admin {
     
        private String oname;
        private String otime;
        private String opickup;
        private String odrop;
        private String usertype;

    public admin() {
    }

    public admin(String oname, String otime, String opickup, String odrop, String usertype) {
        this.oname = oname;
        this.otime = otime;
        this.opickup = opickup;
        this.odrop = odrop;
        this.usertype = usertype;
    }

    public String getOname() {
        return oname;
    }

    public String getOtime() {
        return otime;
    }

    public String getOpickup() {
        return opickup;
    }

    public String getOdrop() {
        return odrop;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setOname(String oname) {
        this.oname = oname;
    }

    public void setOtime(String otime) {
        this.otime = otime;
    }

    public void setOpickup(String opickup) {
        this.opickup = opickup;
    }

    public void setOdrop(String odrop) {
        this.odrop = odrop;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }

    @Override
    public String toString() {
        return "admin{" + "oname=" + oname + ", otime=" + otime + ", opickup=" + opickup + ", odrop=" + odrop + ", usertype=" + usertype + '}';
    }
        
        
}
