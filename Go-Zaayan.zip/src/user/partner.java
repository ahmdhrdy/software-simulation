/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Hp
 */
public class partner {
         
        private String opname;
        private String oppicktime;
        private String pickname;
        private String dropname;

    public partner() {
    }

    public partner(String opname, String oppicktime, String pickname, String dropname) {
        this.opname = opname;
        this.oppicktime = oppicktime;
        this.pickname = pickname;
        this.dropname = dropname;
    }

    public String getOpname() {
        return opname;
    }

    public String getOppicktime() {
        return oppicktime;
    }

    public String getPickname() {
        return pickname;
    }

    public String getDropname() {
        return dropname;
    }

    public void setOpname(String opname) {
        this.opname = opname;
    }

    public void setOppicktime(String oppicktime) {
        this.oppicktime = oppicktime;
    }

    public void setPickname(String pickname) {
        this.pickname = pickname;
    }

    public void setDropname(String dropname) {
        this.dropname = dropname;
    }

    @Override
    public String toString() {
        return "partner{" + "opname=" + opname + ", oppicktime=" + oppicktime + ", pickname=" + pickname + ", dropname=" + dropname + '}';
    }
        
        
     
}
