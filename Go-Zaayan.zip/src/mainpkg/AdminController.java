/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import user.admin;

/**
 * FXML Controller class
 *
 * @author Hp
 */
public class AdminController implements Initializable {

    @FXML
    private TextField onameTextField;
    @FXML
    private TableView<admin> tableview;
    @FXML
    private TableColumn<admin, String> partnerNameTextField;
    @FXML
    private TableColumn<admin, String> timeTextField;
    @FXML
    private TableColumn<admin, String> pickupTextField;
    @FXML
    private TableColumn<admin, String> dropTextField; 
    @FXML
    private TableColumn<admin, String> usertypeTextField;
    @FXML
    private ComboBox<String> usertypTextField;
    @FXML
    private TextField timTextField;
    @FXML
    private TextField pickTextField;
    @FXML
    private TextField drpTextField;
    
    private Scene scene;
    private Stage stage;
    private Parent root;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        usertypTextField.getItems().addAll("Bus","Flight","Hotel");
        partnerNameTextField.setCellValueFactory(new PropertyValueFactory<admin,String>("oname"));
        timeTextField.setCellValueFactory(new PropertyValueFactory<admin,String>("otime"));
        pickupTextField.setCellValueFactory(new PropertyValueFactory<admin,String>("opickup"));
        dropTextField.setCellValueFactory(new PropertyValueFactory<admin,String>("odrop"));
        usertypeTextField.setCellValueFactory(new PropertyValueFactory<admin,String>("usertype"));
        
        //load dummy data
        tableview.setItems(getCode());
        // TODO
    }    
     
    public ObservableList<admin> getCode(){
        ObservableList<admin> Code = FXCollections.observableArrayList();
        return Code;
    } 
       
    @FXML
    private void addOnClick(ActionEvent event) {
            
              admin news = new admin(onameTextField.getText(),
                                        timTextField.getText(),
                                       pickTextField.getText(),
                                       drpTextField.getText(),
                                        usertypTextField.getValue() 
                                    );
        tableview.getItems().add(news);
         
    }

    @FXML
    private void deleteOnClick(ActionEvent event) {
         
         ObservableList<admin> selectedRows, allPeople;
        allPeople = tableview.getItems();
        selectedRows = tableview.getSelectionModel().getSelectedItems();
        
        for(admin p: selectedRows){
            allPeople.remove(p);
        }
         Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setContentText("Partner is  deleted");
        a.showAndWait();
    }

    @FXML
    private void showEarnOnClick(ActionEvent event) throws IOException {
        
         Parent root = FXMLLoader.load(getClass().getResource("earnpieChart.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }
    
}
