/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Hp
 */
public class PartnerController implements Initializable {

    @FXML
    private TextField opnameTextField;
    @FXML
    private TextField oppicktimeTextField;
    @FXML
    private TextField picknameTextField;
    @FXML
    private TextField dropnameTextField;
    @FXML
    private TextArea outputTextArea;
    @FXML
    private TextField oidTextFiled;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addBinaryfileButtonOnClick(ActionEvent event) {
        
        File f = null;
        FileOutputStream fose = null;
        DataOutputStream dose = null;
        try{
            f = new File("partner.bin");
            if (f.exists()) fose = new FileOutputStream(f,true);
            else fose = new FileOutputStream(f);
            dose =new DataOutputStream(fose);
            
            dose.writeUTF(oidTextFiled.getText());
            dose.writeUTF(opnameTextField.getText());
            dose.writeUTF(oppicktimeTextField.getText());
            dose.writeUTF(picknameTextField.getText());
            dose.writeUTF(dropnameTextField.getText());
            
        } catch(IOException ex){
            Logger.getLogger(PartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally {
            try {
                if(dose != null) dose.close();
            } catch (IOException ex) {
                Logger.getLogger(SignupController.class.getName()).log(Level.SEVERE, null, ex);
            }
           
        }
        Alert a = new Alert(AlertType.INFORMATION);
        a.setContentText("New Operator Added");
        a.showAndWait();
    }

    @FXML
    private void withdarwButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void recievePayButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void readBinaryFileButtonOnClick(ActionEvent event) {
        
        outputTextArea.setText("");
        File f = null;
        FileInputStream fise = null;
        DataInputStream dise = null;
        String str = "";
        
        try {
            f = new File("partner.bin");
            if (!f.exists()){
                outputTextArea.setText("Not Found");
            }
            else {
                fise  = new FileInputStream(f);
                dise  = new DataInputStream(fise);
                while(true){
                    str+="oidTextFiled:"+dise.readUTF()+" operator Name :"+dise.readUTF()+":Pickup Time :"+dise.readUTF()+"pickup address:"+dise.readUTF()+"drop point:"+dise.readUTF()+"\n";
                           
                }
            }
        }
        catch (IOException ex) {
            outputTextArea.setText(str);
            Logger.getLogger(PartnerController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(dise != null) dise.close();
            } catch (IOException ex) {
                Logger.getLogger(PartnerController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }          
    }

    @FXML
    private void nameOnClick(MouseEvent event) {
         
                opnameTextField.clear();
    }

    @FXML
    private void fromOnClick(MouseEvent event) {
        
                picknameTextField.clear();
    }

    @FXML
    private void toOnClick(MouseEvent event) {
        
                  dropnameTextField.clear();
    }

    @FXML
    private void picktime(MouseEvent event) {
         
               oppicktimeTextField.clear();
    }

    @FXML
    private void idOnClick(MouseEvent event) {
        
                oidTextFiled.clear();
    }
}
    
    

