/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Hp
 */
public class SignupController implements Initializable {

    @FXML
    private TextField nameTextFiled;
    @FXML
    private TextField emailTextFiled;
    @FXML
    private TextField phoneTextField;
    @FXML
    private TextField passwordTextField;
    @FXML
    private ChoiceBox<String> usertype;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        usertype.getItems().addAll("Passenger","partner","Office Executive","Admin");
    }    
    @FXML
    private void phoneTextFieldOnClick(MouseEvent event) {     
           
                    phoneTextField.clear();
    }

    @FXML
    private void passwordTextFiledOnClick(MouseEvent event) {
           
                  passwordTextField.clear();
    }
    
    @FXML
    private void nameTextFieldOnClick(MouseEvent event) {
           
                  nameTextFiled.clear();
    }

    @FXML
    private void emailTextFiledOnClick(MouseEvent event) {
               
                    emailTextFiled.clear();
    }

    @FXML
    private void appendBinaryFilesignupButtonOnClick(ActionEvent event) {
        
                File f  = null;
                FileOutputStream fos = null;
                DataOutputStream dos = null;
                
                try {
                    f =new File("signup.bin");
                    if(f.exists()) fos = new FileOutputStream(f,true);
                     else fos = new FileOutputStream(f);
                    dos = new DataOutputStream(fos);
                    
            dos.writeUTF(nameTextFiled.getText());
            dos.writeUTF(emailTextFiled.getText());
            dos.writeInt(Integer.parseInt(phoneTextField.getText()));
            dos.writeUTF(passwordTextField.getText());
            dos.writeUTF(usertype.getValue());
            
        }
        catch(IOException ex){
             Logger.getLogger(SignupController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(dos != null) dos.close();
            } catch (IOException ex) {
                Logger.getLogger(SignupController.class.getName()).log(Level.SEVERE, null, ex);
            }
           
        }
            
         Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setContentText("Now you can login");
        a.showAndWait();
        
        File f0  = null;
                FileOutputStream fosm = null;
                DataOutputStream dosm = null;
                
                try {
                    f0 =new File("signup2.bin");
                    if(f0.exists()) fosm = new FileOutputStream(f0,true);
                     else fosm = new FileOutputStream(f0);
                    dosm = new DataOutputStream(fosm);
                    
            dosm.writeUTF(nameTextFiled.getText());
            
            dosm.writeUTF(passwordTextField.getText());
            dosm.writeUTF(usertype.getValue());
            
        }
        catch(IOException ex){
             Logger.getLogger(SignupController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(dosm != null) dosm.close();
            } catch (IOException ex) {
                Logger.getLogger(SignupController.class.getName()).log(Level.SEVERE, null, ex);
            }
           
        }
        
        }   

    @FXML
    private void gobacklogin(ActionEvent event) throws IOException {
        
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }
    }
