/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Hp
 */
public class LoginController implements Initializable {
    
    String name,name2,pass,pass2,type,type2;
    boolean sto = false;
    @FXML
    private TextField nameText;
    @FXML
    private TextField passText;
    @FXML
    private ChoiceBox<String> userText;
    private Scene scene;
    private Stage stage;
    private Parent root;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        userText.getItems().addAll("Passenger","partner","Office Executive","Admin");
    }    

    @FXML
    private void logButtonOnClick(ActionEvent event) throws IOException {
        
         FileInputStream fil =new FileInputStream("signup2.bin");
         DataInputStream o = new DataInputStream(fil) ;
         
         name2  = nameText.getText();
         pass2  = passText.getText();
         type2 = userText.getValue();
         while(!sto){
             name= o.readUTF();
             pass= o.readUTF();
             type= o.readUTF();
             if (name2.equals(name) && pass2.equals(pass) && type2.equals(type)){
                 if (type2.equals("partner")){
                 Parent root = FXMLLoader.load(getClass().getResource("partner.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
         scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
                 }
                 else if (type2.equals("passenger")){
                 Parent root = FXMLLoader.load(getClass().getResource("passenger.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
         scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
                 }
                 else if (type2.equals("officeExecutive")){
                 Parent root = FXMLLoader.load(getClass().getResource("officeExecutive.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
         scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
                 }
                 else if (type2.equals("Admin")){
                 Parent root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
         scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
                 }
             }
         }
    }

    @FXML
    private void signButton(ActionEvent event) throws IOException {
      
        Parent root = FXMLLoader.load(getClass().getResource("signup.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }
    
}
